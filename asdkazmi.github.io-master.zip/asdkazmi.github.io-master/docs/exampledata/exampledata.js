exampleData = {
	"name" : "John Doe",
	"father name" : "Doe",
	"qualification": {
		"school" : {
			"Matric":"Govt School"
		},
		"College" : {
			"FSc": "STU College",
			"BSc": "VWX College"
		},
		"Matric":"Govt School",
		"FSc": "STU College",
		"BSc": "VWX College",
		"MSc": "ABC University of XYZ",
		"MPhil": "Not yet"
	},
	"Address": "PQR City"
}